to run 
java -jar UninformedSearch.jar puzzle.txt